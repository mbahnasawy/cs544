package cs544.exercise13_1;

public interface ICustomerDAO {
	public void save(Customer customer) ;
}
